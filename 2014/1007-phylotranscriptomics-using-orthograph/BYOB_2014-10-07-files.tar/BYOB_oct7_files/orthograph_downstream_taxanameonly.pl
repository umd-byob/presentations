#Pipeline for taking the output of orthograph and getting a tree

#I guess I will do maximum liklihood

#1) merge the genes with the COG group name from across the species sub dirs into a single file.  
#Should be possible to do this with perl or with some commandline tricks (try awk?).  Keep dmel + dwil
#as the outgroup pair since they are present in each.

#2) do a MUSCLE alignment of each COG group constructed.  

#3) Use TRIMAI to trim the alignments and output into PHYLIP (nexus?)

#4) Merge the alignments and build the trees with PAUP 

#Script for step 1 follows

#Apparently, the melanogaster sequence is always the 9th one
#and the wil sequence is always the 16th one.
#!/usr/bin/perl

@inputtaxa = ("td","dm", "tt", "ea", "tw", "sb", "se");

opendir INDIR, "/N/dc2/scratch/joserein/orthograph/allfly/td/aa/";
@inputloci = readdir INDIR;

$root = "/N/dc2/scratch/joserein/orthograph/allfly/";

foreach $locus (@inputloci) {
	if ($locus =~ /^\./) {
		next;
	}
	$tdaapath = $root . "/td/aa/" . $locus;
	$outpath = $root . "/all/" . $locus;
	$drostemp = $root . "/drostemp.fa";
	#EOG7ZDCBJ|.|FBpp0
	`sed '17q;d' $tdaapath > $drostemp`;
	`sed -i 's/'^.*FBpp.*'/\>dmel/g' $drostemp`;
	`cat $drostemp >> $outpath`;
	`sed '18q;d' $tdaapath >> $outpath`;
	print "sed '31q;d' $tdaapath > $drostemp\n";
	`sed '31q;d' $tdaapath > $drostemp`;
	`sed -i 's/'^.*FBpp.*'/\>dwil/g' $drostemp`;
	`cat $drostemp >> $outpath`;
	`sed '32q;d' $tdaapath >> $outpath`;

	foreach $taxa (@inputtaxa) {
		#$name = $taxa . "_comp";
		$taxapath = $root . "/" . $taxa . "/aa/" . $locus;
		$sedline1 = "sed -i 's/'^.*Contig.*'/\>$taxa/g' $taxapath";
		$sedline2 = "sed -i 's/'^.*comp.*'/\>$taxa/g' $taxapath";
		$catline = "tail -2 $taxapath >> $outpath";
		print $sedline1 . "\n";
		`$sedline1`;
		print $sedline2 . "\n";
		`$sedline2`;
		print $catline . "\n";
		`$catline`;
	}
}
