#PBS -l walltime=15:00:00,vmem=16gb,mem=16gb,nodes=8
#PBS -N orthograph
#PBS -M josiereinhardt@gmail.com
#PBS -m e

~/programs/Orthograph-master/orthograph-analyzer -c /N/dc2/scratch/joserein/orthograph/td.conf 
~/programs/Orthograph-master/orthograph-analyzer -c /N/dc2/scratch/joserein/orthograph/sb.conf
~/programs/Orthograph-master/orthograph-analyzer -c /N/dc2/scratch/joserein/orthograph/se.conf
~/programs/Orthograph-master/orthograph-analyzer -c /N/dc2/scratch/joserein/orthograph/ea.conf
~/programs/Orthograph-master/orthograph-analyzer -c /N/dc2/scratch/joserein/orthograph/dm.conf
~/programs/Orthograph-master/orthograph-analyzer -c /N/dc2/scratch/joserein/orthograph/tt.conf
~/programs/Orthograph-master/orthograph-analyzer -c /N/dc2/scratch/joserein/orthograph/tw.conf
