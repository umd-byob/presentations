#!/usr/bin/perl

#example muscle
#muscle < /N/dc2/scratch/joserein/orthograph/allfly/test/all/EOG7ZDCBP.aa.fa > /N/dc2/scratch/joserein/orthograph/allfly/test/all/EOG7ZDCBP.aa.aln.fa

#example trimal
#trimal -in  EOG7ZDCBP.aa.aln.fa -out  EOG7ZDCBP.aa.aln.nex -nexus

#!/usr/bin/perl
$indir = $ARGV[0];

opendir INDIR, "$indir";
@inputloci = readdir INDIR;

$muscpath = $indir . "/muscle/";
$trimpath = $indir . "/trim/";
$phypath = $indir . "/phy/";
	
`mkdir $muscpath`;
`mkdir $trimpath`;
`mkdir $phypath`;

foreach $locus (@inputloci) {
	if ($locus =~ /^\./) {
		next;
	}
	#create output directories

	$inpath = $indir . "/" . $locus;
	$musc = $muscpath . "/" . $locus;
	$trim = $trimpath . "/" . $locus . ".nex";
	$phy = $phypath . "/" . $locus . ".phy";
	
	$muscleline = "muscle < " . $inpath . " > " . $musc;
	print $muscleline . "\n";
	`$muscleline`;
	$trimline = "trimal -in " . $musc . " -out " . $trim . " -nexus";
	print $trimline . "\n";
	`$trimline`;
	$trimline2 = "trimal -in " . $musc . " -out " . $phy . " -phylip"; 
	print $trimline2 . "\n";
	`$trimline2`;
}
