#!/bin/bash

~/Downloads/Orthograph-master/orthograph-manager --create

~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/AAEGY.fa --ogs-version 1 --ogs-taxon-name AAEGY
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/AGAMB.fa --ogs-version 1 --ogs-taxon-name AGAMB
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/ADARL.fa --ogs-version 1 --ogs-taxon-name ADARL
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/ASTEP.fa --ogs-version 1 --ogs-taxon-name ASTEP
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/CQUIN.fa --ogs-version 1 --ogs-taxon-name CQUIN
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/DANAN.fa --ogs-version 1 --ogs-taxon-name DANAN
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/DEREC.fa --ogs-version 1 --ogs-taxon-name DEREC
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/DYAKU.fa --ogs-version 1 --ogs-taxon-name DYAKU
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/DGRIM.fa --ogs-version 1 --ogs-taxon-name DGRIM
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/DPSEU.fa --ogs-version 1 --ogs-taxon-name DPSEU
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/DPERS.fa --ogs-version 1 --ogs-taxon-name DPERS
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/DSECH.fa --ogs-version 1 --ogs-taxon-name DSECH
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/DSIMU.fa --ogs-version 1 --ogs-taxon-name DSIMU
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/DVIRI.fa --ogs-version 1 --ogs-taxon-name DVIRI
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/DMELA.fa --ogs-version 1 --ogs-taxon-name DMELA
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/DWILL.fa --ogs-version 1 --ogs-taxon-name DWILL
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/DMOJA.fa --ogs-version 1 --ogs-taxon-name DMOJA
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/GMORS.fa --ogs-version 1 --ogs-taxon-name GMORS
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/LLONG.fa --ogs-version 1 --ogs-taxon-name LLONG
~/programs/Orthograph-master/orthograph-manager -c /mypath/allfly.conf --load-ogs-peptide /mypath/allfly/PPAPA.fa --ogs-version 1 --ogs-taxon-name PPAPA
